<footer id="footer">
    <div class="row-fluid">
        <div class="span3">
            &copy; Your Company 2013
        </div>
        <div class="span9">
            <ul>
                <li><a href="#">First link</a></li>
                <li>&middot;</li>
                <li><a href="#">Second link</a></li>
            </ul>
        </div>
    </div>
</footer>