<!-- <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
<form action="<?=site_url('admin/addeg')?>" method="post">
  <div class="input_fields_wrap">
      <button class="add_field_button">Add More Fields</button>
      <div>
      <button>Add</button>
  </div>
</form>
<script>
  $(document).ready(function() {
    var max_fields      = 10; 
    var wrapper         = $(".input_fields_wrap"); 
    var add_button      = $(".add_field_button"); 
    
    var x = 1; //initlal text box count
    var counter = 0;
    $(add_button).click(function(e){ /
        e.preventDefault();
        
        if(x < max_fields){ /
            x++; 
            counter++;
            $(wrapper).append('<div><input type="text" name="mytext' + counter + '[]" placeholder="Account Title" required><input type="text" name="mytext' + counter + '[]" placeholder="Description" required><input type="text" name="mytext' + counter + '[]" placeholder="Credit" required><a href="#" class="remove_field">Remove</a></div>'); 
        }

    });
    $(wrapper).on("click",".remove_field", function(e){ //user click on remove text
        e.preventDefault(); $(this).parent('div').remove(); x--;
    })
});
</script> -->

<!DOCTYPE html>
<html>
<head>
    <title>jQuery Testing</title>
    <script type="text/javascript" src="http://code.jquery.com/jquery-1.11.1.js"></script>
    <link rel="stylesheet" href="http://code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
    <script src="http://code.jquery.com/jquery-1.10.2.js"></script>
    <script src="http://code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
    <script type="text/javascript">
        $(document).ready(function() {
            $(".addSpan").click(function() {
                var i = $("#dateTab input") .length + 1;
                $("#dateTab").append($("<label>Date</label><input class='getDate id_"+ i +"' type='text' name='name[]' />").datepicker()); //reinitiate the datepicker
                $("#dateTab").append($("<input type='text'>"));
            });
            $( ".getDate" ).datepicker({
            });
        });    
    </script>
</head>
<body>
<div id="dateTab">
    <label>Select Date</label><input type="text" class="getDate id_1" name="name[]" />
</div>
<span class="addSpan">Add</span>
</body>
</html>