<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class RecruiterModel extends CI_Model {
	function getstatus(){
		return $this->db->get('status')->result_array();
	}
	function addcandidate($data){
		$this->db->insert('candidate',$data);
		return 1;
	}
	function getcandidate($recruiterid){
		$result = $this->db->where('recruiterid',$recruiterid)->get('candidate')->result_array();
		for ($i=0; $i < count($result); $i++) { 
         $result[$i]['company_name'] = $this->getCompanyName($result[$i]['company_name']);
	    }
	    return $result;
	}
	function getCompanyName($id){
		return $this->db->where('id',$id)->get('company_onboarding')->result_array();
	}
	function addinterviewschedule($data,$id){
		$this->db->where('id',$id)->update('candidate',$data);
		return 1;
	}
	function getrecruiterprofile($id){
		return $this->db->where('id',$id)->get('recruiter')->result_array();
	}
	function updaterecruiter($id,$data){
		$this->db->where('id',$id)->update('recruiter',$data);
		return 1;
	}
	function getTime(){
		return $this->db->get('time')->result_array();
	}
	function getcandidateprofile($id){
		$result = $this->db->where('id',$id)->get('candidate')->result_array();
		for ($i=0; $i < count($result); $i++) { 
         $result[$i]['company_name'] = $this->getCompanyName($result[$i]['company_name']);
         $result[$i]['f-status'] = $this->getcandidatestatus($result[$i]['f-status']);
         $result[$i]['s-status'] = $this->getcandidatestatus($result[$i]['s-status']);
         $result[$i]['t-status'] = $this->getcandidatestatus($result[$i]['t-status']);
	    }
	    return $result;
	}
	function getcandidatestatus($id){
		return $this->db->where('id',$id)->get('status')->result_array();
	}
	function getinterviewschedulelist($data1,$recruiterid){
		$data = "SELECT * FROM candidate WHERE (`f-date` = '".$data1."' AND `recruiterid` = '".$recruiterid."') OR (`s-date` = '".$data1."' AND `recruiterid` = '".$recruiterid."') OR (`t-date` = '".$data1."' AND `recruiterid` = '".$recruiterid."')";
		$result = $this->db->query($data)->result_array();
		for ($i=0; $i < count($result); $i++) { 
         $result[$i]['company_name'] = $this->getCompanyName($result[$i]['company_name']);
         $result[$i]['f-status'] = $this->getcandidatestatus($result[$i]['f-status']);
         $result[$i]['s-status'] = $this->getcandidatestatus($result[$i]['s-status']);
         $result[$i]['t-status'] = $this->getcandidatestatus($result[$i]['t-status']);
	    }
	    return $result;
	}
	function getpositionlist($recruiterid){
		$result =  $this->db->where('assign_to_recruiter',$recruiterid)->get('position')->result_array();
		for ($i=0; $i < count($result); $i++) { 
         $result[$i]['company_name'] = $this->getCompanyName($result[$i]['compant_id']);
	    }
	    return $result;
	}
	public function getposition($recruiter_id){
		$position = $this->db->where('assign_to_recruiter',$recruiter_id)->get('position')->result_array();
		// print_r($position);
		for ($i=0; $i < count($position); $i++) { 
			$a = $this->db->get('position')->result_array();
			// print_r($a);
			// $b = explode(',', $a);
			// print_r($b);
			// for ($i=0; $i < count($a); $i++) { 
			// 	$b = explode(',', $a);
			// 	if(count($b) > 1){
			// 		for ($i=0; $i < count($b) ; $i++) { 
			// 			$c = $this->db->where('assign_to_recruiter',$b[$i])->get('position')->result_array();
			// 			print_r($c);
			// 		}
			// 	}else{
			// 		for ($i=0; $i < count($b) ; $i++) { 
			// 			$c = $this->db->where('assign_to_recruiter',$b[$i])->get('position')->result_array();
			// 			print_r($c);
			// 		}
			// 	}
			// }
			// $b = explode(',', $a);
			// print_r($b);
			// if(count($b) > 1){
			// 	for ($i=0; $i < count($b) ; $i++) { 
			// 		$c = $this->db->where('assign_to_recruiter',$b[$i])->get('position')->result_array();
			// 		print_r($c);
			// 	}
			// }else{
			// 	for ($i=0; $i < count($b) ; $i++) { 
			// 		$c = $this->db->where('assign_to_recruiter',$b[$i])->get('position')->result_array();
			// 		print_r($c);
			// 	}
			// }
			
			// if(is_array($b)){
				// $a =json_encode($b);
				// print_r($a);
				// $a = json_decode($a);
				// $ = explode(delimiter, string)
				// print_r($a);	
				// for ($i=0; $i < count($a) ; $i++) { 
				// 	$c = $this->db->where('assign_to_recruiter',$a)->get('position')->result_array();
				// 	// print_r($c);
				// }
			// }else{
			// 	$b = $this->db->where('assign_to_recruiter',$recruiter_id)->get('position')->result_array();
			// }
		}
		// $result = $this->db->where('assign_to_recruiter',$recruiter_id)->get('position')->result_array();
		// print_r($result);
		// die;
	}
}